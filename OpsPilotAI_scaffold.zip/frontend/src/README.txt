Frontend placeholder (React/Vite to be added).
